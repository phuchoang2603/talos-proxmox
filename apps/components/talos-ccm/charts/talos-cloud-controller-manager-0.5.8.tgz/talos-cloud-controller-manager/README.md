# talos-cloud-controller-manager

![Version: 0.5.8](https://img.shields.io/badge/Version-0.5.8-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v1.14.0](https://img.shields.io/badge/AppVersion-v1.14.0-informational?style=flat-square)

Talos Cloud Controller Manager Helm Chart

**Homepage:** <https://github.com/siderolabs/talos-cloud-controller-manager>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| sergelogvinov |  | <https://github.com/sergelogvinov> |

## Source Code

* <https://github.com/siderolabs/talos-cloud-controller-manager>

## Talos machine config

The control plane configuration should be set with the following settings:

```yaml
machine:
  kubelet:
    extraArgs:
      cloud-provider: external
      # For security reasons, it is recommended to enable the rotation of server certificates.
      rotate-server-certificates: true
  features:
    kubernetesTalosAPIAccess:
      enabled: true
      allowedRoles:
        - os:reader
      allowedKubernetesNamespaces:
        - kube-system
```

The worker nodes configuration should include the following settings:

```yaml
machine:
  kubelet:
    extraArgs:
      cloud-provider: external
      # For security reasons, it is recommended to enable the rotation of server certificates.
      rotate-server-certificates: true
```

## Deploy example

```yaml
# talos-ccm.yaml

replicaCount: 2

enabledControllers:
  - cloud-node
  - node-csr-approval
```

Deploy chart:

```shell
helm upgrade -i --namespace=kube-system -f talos-ccm.yaml \
  talos-cloud-controller-manager charts/talos-cloud-controller-manager
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity for data pods assignment. ref: https://kubernetes.io/docs/concepts/configuration/assign-pod-node/#affinity-and-anti-affinity |
| daemonSet | object | `{"enabled":false,"k8s":{"serviceHost":"","servicePort":6443}}` | Deploy CCM  in Daemonset mode. CCM will use hostNetwork and connect to the Kubernetes API server on the current node by default. Optionally you can specify the Kubernetes API server host and port. You can run it without CNI plugin. |
| daemonSet.k8s.serviceHost | string | `""` | Kubernetes API server host. Default is the current node IP. |
| daemonSet.k8s.servicePort | int | `6443` | Kubernetes API server port. Default is 6443. |
| enabledControllers | list | `["cloud-node","node-csr-approval"]` | List of controllers should be enabled. Use '*' to enable all controllers. Support only `cloud-node, cloud-node-lifecycle, node-csr-approval, node-ipam-controller` controllers. |
| extraArgs | list | `[]` | Any extra arguments for talos-cloud-controller-manager |
| fullnameOverride | string | `""` | String to fully override deployment name. |
| globalConfig | object | `{}` | Global cloud config options: clusterName, preferIPv6. |
| image.pullPolicy | string | `"IfNotPresent"` | Pull policy: IfNotPresent or Always. |
| image.repository | string | `"ghcr.io/siderolabs/talos-cloud-controller-manager"` | CCM image repository. |
| image.tag | string | `""` | Overrides the image tag whose default is the chart appVersion. |
| imagePullSecrets | list | `[]` | Optionally specify an array of imagePullSecrets. Secrets must be manually created in the namespace. ref: https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry/ |
| logVerbosityLevel | int | `2` | Log verbosity level. See https://github.com/kubernetes/community/blob/master/contributors/devel/sig-instrumentation/logging.md for description of individual verbosity levels. |
| nameOverride | string | `""` | String to partially override deployment name. |
| nodeSelector | object | `{"node-role.kubernetes.io/control-plane":""}` | Node labels for data pods assignment. ref: https://kubernetes.io/docs/user-guide/node-selection/ |
| podAnnotations | object | `{}` | Annotations for data pods. ref: https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/ |
| podSecurityContext | object | `{"fsGroup":10258,"fsGroupChangePolicy":"OnRootMismatch","runAsGroup":10258,"runAsNonRoot":true,"runAsUser":10258}` | Pods Security Context. ref: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-pod |
| priorityClassName | string | `"system-cluster-critical"` | CCM pods' priorityClassName. |
| replicaCount | int | `1` | Number of CCM replicas to deploy. |
| resources | object | `{"requests":{"cpu":"10m","memory":"64Mi"}}` | Resource requests and limits. ref: http://kubernetes.io/docs/user-guide/compute-resources/ |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"seccompProfile":{"type":"RuntimeDefault"}}` | Container Security Context. ref: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-pod |
| service.annotations | object | `{}` | Additional custom annotations for Service. |
| service.containerPort | int | `10458` | Container HTTPS port. |
| service.port | int | `10458` | Service HTTPS port to expose controller. |
| serviceAccount | object | `{"annotations":{},"create":true,"name":""}` | Pods Service Account. ref: https://kubernetes.io/docs/tasks/configure-pod-container/configure-service-account/ |
| serviceAccount.annotations | object | `{}` | Annotations to add to the service account. |
| serviceAccount.create | bool | `true` | Specifies whether a service account should be created. |
| serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template. |
| tolerations | list | `[{"effect":"NoSchedule","key":"node-role.kubernetes.io/control-plane","operator":"Exists"},{"effect":"NoSchedule","key":"node.cloudprovider.kubernetes.io/uninitialized","operator":"Exists"}]` | Tolerations for data pods assignment. ref: https://kubernetes.io/docs/concepts/configuration/taint-and-toleration/ |
| transformations | list | `[]` | List of node transformations. Available matchExpressions key values: https://github.com/siderolabs/talos/blob/main/pkg/machinery/resources/runtime/platform_metadata.go#L28 |
| updateStrategy | object | `{"rollingUpdate":{"maxUnavailable":1},"type":"RollingUpdate"}` | Deployment update strategy type. ref: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#updating-a-deployment |
